﻿namespace Recuperacion.Models
{
    public class ComprobarRequest
    {
        private List<DepartamentoSeleccionado> Selecciones { get; set; }
    }
}
