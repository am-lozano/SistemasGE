﻿namespace Recuperacion.Models
{
    public class DepartamentoSeleccionado
    {
        private int IdPersona { get; set; }
        private int IdDepartamentoSeleccionado { get; set; }
    }
}
