﻿using Domain.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    internal class IPersonaDepartamentoUseCase
    {
        public Task<List<PersonaConListaDeptDto>> GetListaPersonaConListaDeptDto();
    }
}
